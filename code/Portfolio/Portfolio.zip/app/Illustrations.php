<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Illustrations extends Model
{
    //
    protected $fillable = ['Photo_routes'];
}
