

<?php $__env->startSection("Head"); ?>

<h1 id="h1create">We buy your auto-part. If it is at a good state, we'll call you!</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("Middle"); ?>

<?php echo Form::open(['method'=>'POST','action'=>'Portfolio@store', 'files'=>true]); ?>


<table>

<tr>
<td><?php echo Form::label('Name', 'Name of the product: '); ?></td>

<td><?php echo Form::text('Name'); ?></td></tr>

<tr>
<td><?php echo Form::label('Origin', 'Origin: '); ?></td>

<td><?php echo Form::text('Origin'); ?></td></tr>

<tr>
<td><?php echo Form::label('Price', 'Original price: '); ?></td>

<td><?php echo Form::text('Price'); ?></td></tr>

<tr>
<td><?php echo Form::label('Photo', 'Illustration: '); ?></td>

<td><?php echo Form::file('Photo'); ?></td></tr>

<tr>
  <td><?php echo Form::label('Phone_Number', 'Phone Number: '); ?></td>
  <td><?php echo Form::text('Phone_Number'); ?></td>
</tr>

<tr><td><?php echo Form::submit('Send Product'); ?></td></tr>
<tr><td><?php echo Form::reset('Clean'); ?></td></tr>

</table>

<?php echo Form::close(); ?>   

<?php $__env->stopSection(); ?>

<?php $__env->startSection("Foot"); ?>
<p class="footcreate">
Copyrights © High Tech Auto-Parts 2020 || All rights reserved  ®.
</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Portfolio/resources/views/create.blade.php ENDPATH**/ ?>