

<?php $__env->startSection("Head"); ?>

<h1>
   High Tech Auto-Parts

      <a href="#">
      <nav id="pinterest">            
      </nav>
   </a>
   <a href="#">
      <nav id="twitter"></nav>
   </a>
   <a href="#">
      <nav id="youtube"></nav>
   </a>
   <a href="#">
      <nav id="instagram"></nav>
   </a>
   <a href="#">
      <nav id="tumblr"></nav>
   </a>
</h1>
<h2>
   Material for the Racing Industry
</h2>
<header>
	<div class="main">
	<ul>
		<li><a href="#">Start</a></li>
		<li><a href="#">Showroom</a></li>
		<li><a href="#history">History</a></li>
		<li><a href="#news">News</a></li>
	</ul>
   </div>
</header>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("Middle"); ?>


<section id="mainsection">
 	<h4>Top performances Auto-Parts for your car</h4>
		  <nav>We also buy your auto-parts at a good price.<a href="project/create">Click here!</a></nav>
		  <nav>Find what you're looking for your car.</br> The best site for tunning is here!</nav>	
		  <nav></nav>
</section>

<section id="jszone">
   Check our gallery to know how our team works !
      <!-- galeria Jquery -->
      <!--/top-->
  <div id="header">
    <div class="wrap">
      <div id="slide-holder">
      <div id="slide-runner">
    <a href=""><img id="slide-img-1" src="js_files/images/scientists_working_together_1.jpg" class="slide" alt="" /></a>
    <a href=""><img id="slide-img-2" src="js_files/images/scientists_working_together_2.jpg" class="slide" alt="" /></a>
    <a href=""><img id="slide-img-3" src="js_files/images/scientists_working_together_3.jpg" class="slide" alt="" /></a>
    <a href=""><img id="slide-img-4" src="js_files/images/scientists_working_together_4.jpg" class="slide" alt="" /></a>
    <a href=""><img id="slide-img-5" src="js_files/images/scientists_working_together_5.jpg" class="slide" alt="" /></a>
    <div id="slide-controls">
     <p id="slide-client" class="text"><strong>post: </strong><span></span></p>
     <p id="slide-desc" class="text"></p>
     <p id="slide-nav"></p>
    </div>
</div><!--content featured gallery here -->
   </div>
   <script type="text/javascript">
    if(!window.slider) var slider={};slider.data=[{"id":"slide-img-1","client":"Juan Perez","desc":"Engineers working!"},{"id":"slide-img-2","client":"Carlos Valdiviezo","desc":"The team!"},{"id":"slide-img-3","client":"Ing. Raul Milosevich","desc":"Three minds are better than one"},{"id":"slide-img-4","client":"Facundo Isaias","desc":"Metal to the world"},{"id":"slide-img-5","client":"German Dowler","desc":"Ready the nuclear warheads !"}];
   </script>
  </div>  
</div><!--/header-->
      <!-- fin galeria -->
</section>

<div id="pbOverlay"></div>
  <div class="msie">
    <div class="pbloading">
      <div class="pbWrapper"></div>
    </div>
  </div>
</section>

<section id="zweitschlussfolgerung">
 <div id="erste">
   <div id="milicontractors">Our security & military contractors</div>
   <nav id="FAAargentinas"></nav>
   <nav id="ejercito"></nav>
   <nav id="fuerzaaerea"></nav>
   <nav id="armada"></nav>
   <nav id="gna"></nav>
   <nav id="pna"></nav>
   <nav id="pfa"></nav>
   <nav id="psa"></nav>
   <nav id="usarmy"></nav>
   <nav id="usaf"></nav>
   <nav id="usmc"></nav>
   <nav id="usnavy"></nav>
</div>

<div id="zweite">
   <div id="spacecontractors">Our clients in the airspace & nuclear industry</div>
   <nav id="conae"></nav>
   <nav id="cnea"></nav>
   <nav id="invap"></nav>
   <nav id="nasasmall"></nav>
   <nav id="frenchspace"></nav>
   <nav id="usnrc"></nav>
</div>

 <div id="dreite"> 
   <div id="inteligence">Our intelligence collaborators
   </div> 
   <nav id="afi"></nav>
   <nav id="cia"></nav>
   <nav id="mi6"></nav>
   <nav id="svr"></nav>
</div>
</section>

<section id="grant">
   <div id="grant2"><a href="#">Subscribe to our podcast</a></div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("Foot"); ?>

	<footer>
	<div id="nivelF">
		<ul>
			<li><a href="/users/pages/create" target="new">Contact</a></li>
			<li><a href="#">FAQ</a></li>
			<li><a href="#">Careers</a></li>
			<li><a href="#">Advices</a></li> 
			<li><a href="#">Legal department</a></li>
		</ul>
	</div>
</footer>

<p>Copyrights © High Tech Auto-Parts  || All rights reserved  ®.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/code/Portfolio/resources/views/users/pages/index.blade.php ENDPATH**/ ?>